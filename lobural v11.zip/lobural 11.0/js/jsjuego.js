var imagenes = new Array();	//cargamos en cada posición del array una imagen
var cartas = new Array(); //array de objetos Carta que correspoden con cada imagen
var cartastab = new Array(); //array de objetos Carta pero por la parte de atras
var numFilas = 2;
var numColumnas = 4; //como maximo 5
var dimension = numFilas * numColumnas; //tiene que ser par
const esp = 110; //el espacio que se quiera entre fichas
const dorso = new Image();
dorso.src = "img/dorso.jpg";

/*Función que carga las imagenes en un array. Carga la mitad de las fotos necesarias
para que haya dos cartas de cada tipo en el tablero*/
function cargaimagenes() {
	for(i=0;i<dimension;i++) {
		imagenes[i] = new Image();
		if(i<(dimension/2)) {
			imagenes[i].src = "img/" + i + ".jpg";
		}else{
			pos = i-(dimension/2);
			imagenes[i].src = "img/" + pos + ".jpg";
		}
	}
}

/*Constructor del objeto Carta, con parámetros imagen, indice y posicion*/
function Carta(img,ind,pos) {
	this.img = img; //objeto Imagen, que a su vez tiene alto y ancho
	this.ind = ind; //numero que asociaremos a cada imagen distinta
	this.pos = pos; //posicion asociada de la carta en el tablero
}

/*Función que desoderna las cartas*/
function aleatorizarcartas() {
	cartas.sort(function() {return Math.random() - 0.5}); //desordenar array
	//Referencia: https://www.ngeeks.com/javascript-avanzado-desordenar-un-array/
}

/*Función que hace un array de objetos Carta y le introduce las imagenes del 
array de imagenes. Le asigna un indice a cada imagen, y le asigna tambien una 
posicion tras desordenarlo*/
function cargacartas(){
	for(i=0;i<dimension;i++) {
		cartas[i] = new Carta();
		cartas[i].img = imagenes[i];
		if(i<(dimension/2)) {
			cartas[i].ind = i;
		}else{
			cartas[i].ind = i - dimension/2;
		}
	}
	aleatorizarcartas();
	for(i=0;i<dimension;i++) {
		cartas[i].pos = i;
	}
}

// /*Función que ordena de forma aleatoria el array de imagenes*/
// function aleatorizar(){
	// imagenes.sort(function() {return Math.random() - 0.5}); //desordenar array
	//Referencia: https://www.ngeeks.com/javascript-avanzado-desordenar-un-array/
// }



/*Función que nos da el tablero de juego. Asocia a cada ficha del tablero una carta*/
function cargatablero(){
	for(i=0;i<dimension;i++) {
		cartastab[i] = new Carta();
		cartastab[i].img = dorso;
		cartastab[i].pos = cartas[i].pos;
		cartastab[i].ind = cartas[i].ind;
	}
}


// /*Función auxiliar que nos dibuja el array de carga en el canvas para verificar que funciona*/
// function muestraimagenes(){
	// var ctx = document.getElementById('myCanvas').getContext('2d');
	// for(i=0;i<dimension;i++) {
		// ctx.drawImage(imagenes[i], (i*esp), 0);
	// }
// }

// /*Función auxiliar que nos dibuja el array de carga en el canvas para verificar que funciona*/
// function muestracartas(){
	// var ctx = document.getElementById('myCanvas').getContext('2d');
	// for(i=0;i<dimension;i++) {
		// ctx.drawImage(cartas[i].img, (i*esp), 300);
	// }
// }

// /*Función auxiliar para probar a dibujar el tablero*/
// function tablero() {
	// var ctx = document.getElementById('myCanvas').getContext('2d');
	// for(i=0;i<dimension;i++) {
		// if(i<numColumnas) {
			// ctx.drawImage(dorso, (i*esp), 0);
		// }else if(i<numColumnas*2) {
			// ctx.drawImage(dorso, (i*esp - numColumnas*esp), esp*1);
		// }else if(i<numColumnas*3) {
			// ctx.drawImage(dorso, (i*esp - numColumnas*esp*2), esp*2);
		// }else if(i<numColumnas*4) {
			// ctx.drawImage(dorso, (i*esp - numColumnas*esp*3), esp*3);
		// }else if(i<numColumnas*5) {
			// ctx.drawImage(dorso, (i*esp - numColumnas*esp*4), esp*4);
		// }
	// }
// }

// /*Función auxiliar para ver en que posicion esta cada imagen*/
// function matrizimagenes(){
	// var ctx = document.getElementById('myCanvas').getContext('2d');
	// for(i=0;i<dimension;i++) {
		// if(i<numColumnas) {
			// ctx.drawImage(imagenes[i], (i*esp), 200);
		// }else if(i<numColumnas*2) {
			// ctx.drawImage(imagenes[i], (i*esp - numColumnas*esp), 200+esp*1);
		// }else if(i<numColumnas*3) {
			// ctx.drawImage(imagenes[i], (i*esp - numColumnas*esp*2), 200+esp*2);
		// }else if(i<numColumnas*4) {
			// ctx.drawImage(imagenes[i], (i*esp - numColumnas*esp*3), 200+esp*3);
		// }else if(i<numColumnas*5) {
			// ctx.drawImage(imagenes[i], (i*esp - numColumnas*esp*4), 200+esp*4);
		// }
	// }
// }


/*Función auxiliar para ver si es igual que la matriz de imagenes. No hace nada 
en el juego, pero nos es útil para programar*/
function matrizcartas(){
	ctx = document.getElementById('myCanvas').getContext('2d');
	for(i=0;i<dimension;i++) {
		if(i<numColumnas) {
			ctx.drawImage(cartas[i].img, (i*esp), 220);
		}else if(i<numColumnas*2) {
			ctx.drawImage(cartas[i].img, (i*esp - numColumnas*esp), 220+esp*1);
		}else if(i<numColumnas*3) {
			ctx.drawImage(cartas[i].img, (i*esp - numColumnas*esp*2), 220+esp*2);
		}else if(i<numColumnas*4) {
			ctx.drawImage(cartas[i].img, (i*esp - numColumnas*esp*3), 220+esp*3);
		}else if(i<numColumnas*5) {
			ctx.drawImage(cartas[i].img, (i*esp - numColumnas*esp*4), 220+esp*4);
		}
	}
}

/*Función que nos dibuja el tablero*/
function matriztablero(){
	ctx = document.getElementById('myCanvas').getContext('2d');
	for(i=0;i<dimension;i++) {
		if(i<numColumnas) {
			ctx.drawImage(cartastab[i].img, (i*esp), 0);
		}else if(i<numColumnas*2) {
			ctx.drawImage(cartastab[i].img, (i*esp - numColumnas*esp), esp*1);
		}else if(i<numColumnas*3) {
			ctx.drawImage(cartastab[i].img, (i*esp - numColumnas*esp*2), esp*2);
		}else if(i<numColumnas*4) {
			ctx.drawImage(cartastab[i].img, (i*esp - numColumnas*esp*3), esp*3);
		}else if(i<numColumnas*5) {
			ctx.drawImage(cartastab[i].img, (i*esp - numColumnas*esp*4), esp*4);
		}
	}
}

/*Función que nos devuelve las coordenadas del canvas*/
	//Referencia: https://www.youtube.com/watch?v=Mbx527ZLQC8&t=349s
function cordCanvas(c,evt) {
	var rect = c.getBoundingClientRect();
	return {
		x: evt.clientX - rect.left,
		y: evt.clientY - rect.top
	};
}

/*Función que esta escuchando si se hace click en el canvas. Si se pincha en 
el espacio asociado a una carta, la reconoce. Devuelve la carta clickada*/
function quecartaes(e){
	evento = e || window.event;
	p = cordCanvas(myCanvas, evento);
	aux = new Carta();
	if((numFilas == 2) && (numColumnas == 4)){ //si modo fácil
		if((p.y>100)&&(p.y<200)) { //si primera fila
			if((p.x>0)&&(p.x<100)){ //si primera columna de primera fila
				aux = cartas[0];
			}else if((p.x>esp)&&(p.x<esp+100)){
				aux = cartas[1];
			}else if((p.x>esp*2)&&(p.x<esp*2+100)){
				aux = cartas[2];
			}else if((p.x>esp*3)&&(p.x<esp*3+100)){
				aux = cartas[3];
			}
		}else if((p.y>100+esp)&&(p.y<200+esp)){//si segunda fila
			if((p.x>0)&&(p.x<100)){ //si primera columna de segunda fila
				aux = cartas[4];
			}else if((p.x>esp)&&(p.x<esp+100)){
				aux = cartas[5];
			}else if((p.x>esp*2)&&(p.x<esp*2+100)){
				aux = cartas[6];
			}else if((p.x>esp*3)&&(p.x<esp*3+100)){
				aux = cartas[7]
			}
		}
	}
	//alert("indice:"+aux.ind+", posición:"+aux.pos);
	return aux;
}

/*Función que hace que se vea el reverso de la ficha si la pinchas*/
function mostrar() {
	indice = quecartaes().ind;
	posicion = quecartaes().pos;
	switch(posicion) {
		case 0:
		cartastab[0] = cartas[0];
		matriztablero();
		break;
		case 1:
		cartastab[1] = cartas[1];
		matriztablero();
		break;
		case 2:
		cartastab[2] = cartas[2];
		matriztablero();
		break;
		case 3:
		cartastab[3] = cartas[3];
		matriztablero();
		break;
		case 4:
		cartastab[4] = cartas[4];
		matriztablero();
		break;
		case 5:
		cartastab[5] = cartas[5];
		matriztablero();
		break;
		case 6:
		cartastab[6] = cartas[6];
		matriztablero();
		break;
		case 7:
		cartastab[7] = cartas[7];
		matriztablero();
		break;
		case 8:
		cartastab[8] = cartas[8];
		matriztablero();
		break;
		case 9:
		cartastab[9] = cartas[9];
		matriztablero();
		break;
		case 10:
		cartastab[10] = cartas[10];
		matriztablero();
		break;
		case 11:
		cartastab[11] = cartas[11];
		matriztablero();
		break;
		case 12:
		cartastab[12] = cartas[12];
		matriztablero();
		break;
		case 13:
		cartastab[13] = cartas[13];
		matriztablero();
		break;
		case 14:
		cartastab[14] = cartas[14];
		matriztablero();
		break;
		case 15:
		cartastab[15] = cartas[15];
		matriztablero();
		break;
		case 16:
		cartastab[16] = cartas[16];
		matriztablero();
	}		
}

function nomostrar(posicion){
	cartastab[posicion].img = dorso;
	matriztablero();
}

var carta1 = new Carta();
carta1.ind = -1;
var	carta2 = new Carta();
carta2.ind = -1;

function delay(ms) { 
//Referencia: https://desarrolloweb.com/faq/81.php
	for(i=0;i<=ms;i++) {
		setTimeout('return 0',1);
	}	
}

function comparar() {
	indice = quecartaes().ind;
	posicion = quecartaes().pos;
	
	if(carta1.ind == -1) {
		mostrar();
		carta1.ind = indice;
	}else if(carta2.ind == -1) {
		mostrar();
		carta2.ind = indice;
		//delay(500);
		if(carta1.ind != carta2.ind) {
			cartastab[posicion].img = dorso;
			matriztablero();
		}else{
		}
		carta1.ind = -1;
		carta2.ind = -1;
	}	
}


// /*Función que hace que se vea el reverso de la ficha si la pinchas*/
// function mostrar(e) {
	// evento = e || window.event;
	// p = cordCanvas(myCanvas, evento);
	
	// if((numFilas == 2) && (numColumnas == 4)){ //si modo fácil
		// if((p.y>100)&&(p.y<200)) { //si primera fila
			// if((p.x>0)&&(p.x<100)){ //si primera columna de primera fila
				// cartastab[0] = cartas[0]; //entonces damos la vuelta a la carta
				// matriztablero(); //lo mostramos
			// }else if((p.x>esp)&&(p.x<esp+100)){
				// cartastab[1] = cartas[1];
				// matriztablero();
			// }else if((p.x>esp*2)&&(p.x<esp*2+100)){
				// cartastab[2] = cartas[2];
				// matriztablero();
			// }else if((p.x>esp*3)&&(p.x<esp*3+100)){
				// cartastab[3] = cartas[3];
				// matriztablero();
			// }
		// }else if((p.y>100+esp)&&(p.y<200+esp)){//si segunda fila
			// if((p.x>0)&&(p.x<100)){ //si primera columna de segunda fila
				// cartastab[4] = cartas[4];
				// matriztablero();
			// }else if((p.x>esp)&&(p.x<esp+100)){
				// cartastab[5] = cartas[5];
				// matriztablero();
			// }else if((p.x>esp*2)&&(p.x<esp*2+100)){
				// cartastab[6] = cartas[6];
				// matriztablero();
			// }else if((p.x>esp*3)&&(p.x<esp*3+100)){
				// cartastab[7] = cartas[7];
				// matriztablero();
			// }
		// }
	// }
// }

// /*Función que está escuchando si clickas en el Canvas*/
// function clickado(e){
	// var p = cordCanvas(myCanvas, e);
	// px = p.x;
	// py = p.y;
	////alert("X,Y="+px+","+py);
// }


window.onload = function() {
	canvas = document.getElementById('myCanvas');
	ctx = canvas.getContext('2d');
	//canvas.addEventListener('click',clickado);
	//canvas.addEventListener('click',mostrar);
	canvas.addEventListener('click',quecartaes);
	//tablero();
	cargaimagenes();
	//aleatorizar();
	//muestraimagenes();
	cargacartas();
	//muestracartas();
	cargatablero();
	//matrizimagenes();
	//matrizcartas();
	matriztablero();

}
window.onclick = function(){
	mostrar();
	//comparar();
}